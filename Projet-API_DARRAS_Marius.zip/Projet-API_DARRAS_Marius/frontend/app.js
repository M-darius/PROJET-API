let cart = JSON.parse(localStorage.getItem('cart')) || [];


function fetchProducts() {
  fetch('http://localhost:3000/api/teddies') 
    .then(response => response.json())
    .then(products => {
      displayProducts(products);
    })
    .catch(error => console.error('Erreur:', error));
}

function displayProducts(products) {
  const productList = document.getElementById('product-list');
  products.forEach(product => {
    const productCard = document.createElement('div');
    productCard.classList.add('product-card');
    productCard.innerHTML = `
      <a href="produit.html?id=${product._id}"><img src="${product.imageUrl}" alt="${product.name}" style="width: 150px;"></a>
      <h3>${product.name}</h3>
      <p>${product.price} €</p>
      <a href="produit.html?id=${product._id}" >Voir produit</a>
    `;
    productList.appendChild(productCard);
  });
}

function fetchProductDetails() {
  const urlParams = new URLSearchParams(window.location.search);
  const productId = urlParams.get('id');

  fetch(`http://localhost:3000/api/teddies/${productId}`)
    .then(response => response.json())
    .then(product => {
      displayProductDetails(product);

      document.querySelector('button').addEventListener('click', () => {
        addToCart(product._id, product.name, product.price, product.imageUrl);
      });
    })
    .catch(error => console.error('Erreur:', error));
}

function displayProductDetails(product) {
  const productDetail = document.getElementById('product-detail');
  productDetail.innerHTML = `
    <img src="${product.imageUrl}" alt="${product.name}" style="width: 250px;">
    <div>
      <h2>${product.name}</h2>
      <p>${product.description}</p>
      <p>Prix: ${product.price} €</p>
      <label for="color">Choisir la couleur: </label>
      <select id="color">
        ${product.colors.map(color => `<option value="${color}">${color}</option>`).join('')}
      </select>
      <label for="quantity">Quantité: </label>
      <input type="number" id="quantity" min="1" value="1">
      <button>Ajouter au panier</button>
    </div>
  `;
}

function removeFromCart(index) {
  cart.splice(index, 1); 
  localStorage.setItem('cart', JSON.stringify(cart)); 
  displayCart(); 
}

function displayCart() {
  const cartItems = document.getElementById('cart-items');
  cartItems.innerHTML = ''; 
  let totalPrice = 0;

  cart.forEach((item, index) => {
      const cartItem = document.createElement('div');
      cartItem.classList.add('cart-item');

      cartItem.innerHTML = `
          <img src="${item.imageUrl}" alt="${item.name}">
          <div class="cart-item-info">
              <p>${item.name}</p>
              <p>${item.price} €</p>
              <p>Quantité: ${item.quantity}</p>
              <p class="color">Couleur: ${item.color}</p> <!-- Afficher la couleur ici -->
          </div>
          <button class="remove-btn" onclick="removeFromCart(${index})">Retirer</button>
      `;
      cartItems.appendChild(cartItem);

      totalPrice += item.price * item.quantity;
  });

  document.getElementById('cart-total-price').textContent = `${totalPrice} €`;
}

function submitOrder(event) {
  event.preventDefault();
  
  const contact = {
    firstName: document.getElementById('firstName').value,
    lastName: document.getElementById('lastName').value,
    email: document.getElementById('email').value,
    address: document.getElementById('address').value,
    city: document.getElementById('city').value,
  };

  const products = cart.map(item => item.id);

  if (products.length === 0) {
    alert("Votre panier est vide !");
    return;
  }

  const totalPrice = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const order = { contact, products, total: totalPrice };
  fetch('http://localhost:3000/api/teddies/order', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(order),
  })
    .then(response => response.json())
    .then(orderData => {
      localStorage.removeItem('cart'); 
      window.location.href = `confirmation.html?orderId=${orderData.orderId}&total=${totalPrice}`;
    })
    .catch(error => console.error('Erreur:', error));
}

function displayOrderConfirmation() {
  const urlParams = new URLSearchParams(window.location.search);
  const orderId = urlParams.get('orderId');
  const totalPrice = urlParams.get('total'); 

  const orderIdElement = document.getElementById('order-id');
  const totalElement = document.getElementById('order-total');

  orderIdElement.textContent = orderId;
  totalElement.textContent = `${totalPrice}`; 
}

document.addEventListener('DOMContentLoaded', () => {
  const page = window.location.pathname.split('/').pop();
  if (page === 'index.html') {
    fetchProducts();
  } else if (page === 'produit.html') {
    fetchProductDetails();
  } else if (page === 'panier.html') {
    displayCart();
    document.getElementById('order-form').addEventListener('submit', submitOrder);
  } else if (page === 'confirmation.html') {
    displayOrderConfirmation();
  }
})

function updateCartCount() {
  const cart = JSON.parse(localStorage.getItem('cart')) || [];
  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);
  document.getElementById('cart-count').textContent = cartCount;
}

document.addEventListener('DOMContentLoaded', updateCartCount);

function addToCart(id, name, price, imageUrl) {
  const color = document.getElementById('color').value;
  const quantity = parseInt(document.getElementById('quantity').value);

  const product = { id, name, price, imageUrl, color, quantity };
  let cart = JSON.parse(localStorage.getItem('cart')) || [];
  cart.push(product);
  localStorage.setItem('cart', JSON.stringify(cart));

  updateCartCount();

  const notification = document.getElementById('notification');
  notification.style.display = 'block';
  setTimeout(() => {
    notification.style.display = 'none';
  }, 3000);
}
